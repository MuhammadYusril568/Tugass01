import akademis.MataKuliah;

public class Main {
    public static void main(String[] args) {

        Mahasiswa m1 = new Mahasiswa("2410020120", "Muhammad Yusril", 3.75, 4);

        System.out.println("=== DATA MAHASISWA ===");
        m1.tampil();

        System.out.println("\n=== DATA MATA KULIAH ===");

        MataKuliah mk1 = new MataKuliah("IF101", "Pemrograman");

        mk1.tampil();
    }
}